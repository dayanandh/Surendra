function getDetails()
{
	var Bonus ="";
	Bonus=Basic Salary*0.20;
	var Gross Salary=(Basic Salary+HRA+DA+Bonus)-Deduction;
	
	
	
    var details="";
    details=document.getElementById("empName").value;
    var cnt=document.getElementById("mobile").value;
    details=details+"contact"+cnt;
    var email=document.getElementById("email").value;
    details=details+"email="+email;
    //var addr=document.getElementById("addr").value;
    //details=details+"addr="+addr;
    var proofs=document.getElementsByName("proof");
    for(var i=0;i<proofs.length;i++)
    {
        if(proofs[i].checked)
        {
            details=details+"proof ="+proofs[i].value;
        }
    }

var gender=document.getElementsByName("gender");
for(var i=0;i<gender.length;i++)
{
    if (gender[i].checked)
    {
        details=details+"gender="+gender[i].value;
    }
}

 var loanamount = "";
 //document.write(time);
 document.write("<br />");
 //document.write(now.toLocaleTimeString()));
 if (loanamount < 50000)&&(loanamount<100000)
 {
  document.write("<b> 1 year</b>");
 }
 else if((time >100001) && (time <200000))
 {
  document.write("<b>5 years</b>");
 }
 else if ((time > 200001) && (time <300000 ))
 {
  document.write("<b>10 years</b>");
 }

document.emp.grosssal.value=tsal;
confirm("the total net salary of emp is:" +loanamount);
}

var tsal=bsal+hra+da+bonus+pf-deduc;

document.emp.grosssal.value=tsal;
confirm("the total net salary of emp is:" +tsal);
}
document.write(details);
document.getElementById("Gross Salary");
}