﻿using System;

namespace EmployeeAPI.Models
{
    internal class keyAttribute : Attribute
    {
    }
}