﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HelloWorldWebApp
{
    public partial class Calculator1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int Number1 = int.Parse(TextBox1.Text);
            int Number2 = int.Parse(TextBox2.Text);
            if(ddlOperation.SelectOperation=="Add")
            {
                Result.Text = (Number1 + Number2).ToString();
            }
            else if(ddlOperation.Selectvalue == "Sub")
            {
                Result.Text = (Number1 - Number2).ToString();
            }
            else if (ddlOperation.Selectvalue == "mul")
            {
                Result.Text = (Number1 * Number2).ToString();
            }
            else if (ddlOperation.Selectvalue == "div")
            {
                Result.Text = (Number1 /Number2).ToString();
            }
        }
    }
    
}