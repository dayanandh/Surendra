﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HelloWorldWebApp
{
    public partial class PostBack : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

            if(DropDownList1.SelectedValue=="tamilnadu")
            {
                DropDownList1.Items.Add("chennai");
                DropDownList2.Items.Add("pondicherry");
                
            }
            else if(DropDownList2.SelectedValue=="hyderabad")
            {
                DropDownList1.Items.Add("kukatpally");
                DropDownList2.Items.Add("kphb");

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DropDownList1.Text = "you are selected as :"
                + DropDownList1.Text + " and city as :"
                + DropDownList2;
        }
    }
}