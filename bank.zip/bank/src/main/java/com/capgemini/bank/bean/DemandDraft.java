package com.capgemini.bank.bean;

import java.sql.Date;

public class DemandDraft {

	private int transactionId;
	private String customerName;
	private String inFavourOf;
	private String phoneNumber;
	private Date dateOfTransaction;
	private double ddAmount;
	private double ddCommision;
	private String ddDescription;
	
	public DemandDraft() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public DemandDraft( String customerName, String inFavourOf, String phoneNumber,
			 double ddCommision,double ddAmount, String ddDescription) {
		super();
		this.customerName = customerName;
		this.inFavourOf = inFavourOf;
		this.phoneNumber = phoneNumber;
		this.ddAmount = ddAmount;
		this.ddCommision=ddCommision;
		this.ddDescription = ddDescription;
	}

	public int getTransactionId() {
		return transactionId;
	}
	public int setTransactionId(int transactionId) {
		return this.transactionId = transactionId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInFavourOf() {
		return inFavourOf;
	}
	public void setInFavourOf(String inFavourOf) {
		this.inFavourOf = inFavourOf;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public Date setDateOfTransaction(Date dateOfTransaction) {
	return	this.dateOfTransaction=dateOfTransaction;
		
	}
	public double getDdAmount() {
		return ddAmount;
	}
	public void setDdAmount(double ddAmount) {
		this.ddAmount = ddAmount;
	}
	public double getDdCommision() {
		return ddCommision;
	}
	public void setDdCommision(double ddCommision) {
		this.ddCommision = ddCommision;
	}
	public String getDdDescription() {
		return ddDescription;
	}
	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}
	@Override
	public String toString() {
		return "DemandDraft [transactionId=" + transactionId + ", customerName=" + customerName + ", inFavourOf="
				+ inFavourOf + ", phoneNumber=" + phoneNumber + ", dateOfTransaction=" + dateOfTransaction
				+ ", ddAmount=" + ddAmount + ", ddCommision=" + ddCommision + ", ddDescription=" + ddDescription + "]";
	}
	
}
