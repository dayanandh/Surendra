package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO {

	private Connection conn;

	DemandDraft dd = new DemandDraft();

	public void openConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@ndaoracle:1521:orcl11g", "lab2ctrg33", "lab2coracle");
		conn.setAutoCommit(false);
	}

	public void closeConnection() throws SQLException {
		conn.close();
	}

	public int addDemandDraftDetails(DemandDraft demandDraft) {

		int result = 0;
		try {
			openConnection();
			String query = "insert into demand_draft (transaction_id,customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description)values(transaction_id_sequence.nextVal,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(query);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select transaction_id_sequence.nextVal from demand_draft");

			int transactionId = 0;
			if (rs.next()) {
				transactionId = rs.getInt(1);
			}

			/* ps.setInt(1, transactionId); */
			ps.setString(1, dd.getCustomerName());
			ps.setString(2, dd.getInFavourOf());
			ps.setString(3, dd.getPhoneNumber());
			Date now = new Date();
			java.sql.Date sqlDate = new java.sql.Date(now.getTime());
			ps.setDate(4, dd.setDateOfTransaction(sqlDate));
			ps.setDouble(5, dd.getDdAmount());
			ps.setDouble(6, dd.getDdCommision());
			ps.setString(7, dd.getDdDescription());
			result = ps.executeUpdate();
			conn.commit();
			ps.close();
			closeConnection();
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return result;
	}

	public DemandDraft getDemandDraftDetails(int transactionId) {

		try {
			openConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from demand_draft where transaction_id=" + transactionId);
			while (rs.next()) {
				System.out.println(rs.getInt(1));
				dd.setTransactionId(rs.getInt(1));
				dd.setCustomerName(rs.getString(2));
				dd.setInFavourOf(rs.getString(3));
				dd.setPhoneNumber(rs.getString(4));
				dd.setDateOfTransaction(rs.getDate(5));
				dd.setDdAmount(rs.getDouble(6));
				dd.setDdCommision(rs.getDouble(7));
				dd.setDdDescription(rs.getString(8));
			}
			System.out.println(dd.toString());
			closeConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dd;
	}

}
