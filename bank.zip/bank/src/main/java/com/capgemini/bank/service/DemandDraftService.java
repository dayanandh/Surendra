package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;

public class DemandDraftService implements IDemandDraftService{

	IDemandDraftDAO dd=new DemandDraftDAO();
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		// TODO Auto-generated method stub
		return dd.addDemandDraftDetails(demandDraft);
	}

	public DemandDraft getDemandDraftDetails(int transactionId) {
		// TODO Auto-generated method stub
		return dd.getDemandDraftDetails(transactionId);
	}


}
