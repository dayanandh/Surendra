package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;



public class Client {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		char c;
		IDemandDraftService dds = new DemandDraftService();
		do {
			System.out.println("1. Enter Demand Draft Details");
			System.out.println("2. Print Demand Draft");
			System.out.println("3. EXIT");
			System.out.println("Enter your choice");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				System.out.println("Enter Customer Name:");
				String custname = sc.next();
				System.out.println("Enter Customer Phone Number");
				String custPhoneNumber = sc.next();
				System.out.println("Enter In Favour of");
				String inFavourOf = sc.next();
				System.out.println("Enter Demand Draft Amount");
				double amount=sc.nextDouble();
				double ddamount;
				if(amount<5000) {
					ddamount=10;
				}else if(amount>5001 && amount<10000) {
					ddamount=41;
				}else if(amount>10001 && amount<100000) {
					ddamount=51;
				}else if(amount>100001&&amount<500000){
					ddamount=306;
				}
				else {
					ddamount=307;
				}
				System.out.println("Enter DD Description");
				String ddDescription=sc.next();
				DemandDraft dd=new DemandDraft(custname, inFavourOf, custPhoneNumber, amount,ddamount,ddDescription);
						
				int result;
				try {
					result = dds.addDemandDraftDetails(dd);

					if (result==1) {
						System.out.println("Demand Draft Details Added Successfully");
					} else {
						System.out.println("Demand Draft Details Not Added");
					}
				} catch (Exception e) {
					System.out.println(e);
				}
				break;
			case 2:
				System.out.println("Enter Transaction Id");
				int id=sc.nextInt();
			System.out.println(dds.getDemandDraftDetails(id));
				break;
			case 3:
				System.out.println("Thank you for using this service");
				System.exit(0);
				break;
			}
			System.out.println("Do you want to continue Y/N");
			c = sc.next().charAt(0);
		} while (c == 'Y' || c == 'y');


	}

}
