import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponentComponent } from './employee-list-component/employee-list-component.component';
import { EmployeeAddComponent } from './employee-add/employee-add.component';
import { EmployeeEditComponent } from './employee-edit/employee-edit.component';

const routes: Routes = [
  {
    path:'employees',
    component:EmployeeListComponentComponent,
    data:{title:'Employee List'}


  },
  {
    path:'add',
    component:EmployeeAddComponent,
    data:{title:'Add New employee'}


  },
  {
    path:'edit/:id',
    component:EmployeeEditComponent,
    data:{title:'Edit  employee'}


  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
