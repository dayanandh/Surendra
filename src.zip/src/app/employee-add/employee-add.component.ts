import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm} from '@angular/forms';
import { EmployeeServiceService } from '../employee-service.service';
import { Router } from '@angular/router';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {
  employeeForm:FormGroup;
  Name:string;
  DateOfBirth:Date;
  DateOfJoining:Date;
  Department:string;
  Salary:number;
  constructor(private formBuilder:FormBuilder,private empService:EmployeeServiceService,
    private router:Router) { }

  ngOnInit() {
    this.employeeForm=this.formBuilder.group ({
      Name:[null,Validators.required],
      DateOfBirth:[null,Validators.required],
      DateOfJoining:[null,Validators.required],
      Department:[null,Validators.required],
      Salary:[null,Validators.required]
    })
  
  }
  onFormSubmit(form:NgForm)
  {
    this.empService.AddEmployee(form)
    .subscribe(res=>{console.log('Employee Added');
  this.router.navigate(['/employees'])
  },
    

  err=> console.log(err));
  }
}
    

    
  
  


