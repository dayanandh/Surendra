import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { EmployeeServiceService } from '../employee-service.service';
import { Employee } from '../employee';
import { ActivatedRouteSnapshot, Router } from '@angular/router';

@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {

  employeeForm:FormGroup;
  Id:number;
  Name:string;
  DateOfBirth:Date;
  DateOfJoining:Date;
  Department:string;
  Salary:number;
  constructor(private formBuilder:FormBuilder,private empService:EmployeeServiceService,
    private route:ActivatedRouteSnapshot,
  private router:Router) { }

  ngOnInit() {
    this.getEmployee(this.route.snapshot.params['id']);
    this.employeeForm=this.formBuilder.group ({
      Id:[null,Validators.required],
      Name:[null,Validators.required],
      DateOfBirth:[null,Validators.required],
      DateOfJoining:[null,Validators.required],
      Department:[null,Validators.required],
      Salary:[null,Validators.required]
    })
  
  }
  getEmployee(id){
    this.empService.getEmployeeById(id).subscribe(data =>{
      this.Id= data.Id;
      this.employeeForm.setValue({
        Id:data.Id,
        name:data.Name,
        DateOfBirth:data.DateOfBirth,
        DateOfJoining:data.DateOfJoining,
        Department:data.Department,
        Salary:data.Salary,
      })
    })
  }
  onFormSubmit(form:NgForm)
  {
    this.empService.updateEmployee(
      this.Id, form)
      .subscribe(res=>{ console.log('Employee added');
      this.router.navigate(['/employees']);
    },
    err=> console.log(err));
    }

}
