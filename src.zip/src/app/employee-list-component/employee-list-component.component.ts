import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../employee';
import { EmployeeServiceService } from '../employee-service.service';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'app-employee-list-component',
  templateUrl: './employee-list-component.component.html',
  styleUrls: ['./employee-list-component.component.css']
})
export class EmployeeListComponentComponent implements OnInit {
employeeList:Employee[];
  constructor(private empService:EmployeeServiceService) { }
  

  ngOnInit() {
    ///this.employeeList=this.empService.getEmployeeList();
    this.empService.getEmployeeList()
    .subscribe(employees=>this.employeeList=employees);
  }
  deleteEmployee(id: number)
{
  console.log('delete ' + id);
  this.empService.deleteEmployee(id)
  .subscribe(res => {

  },
err => console.log(err));
}
}
