import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Employee } from './employee';
import { HttpClient, HttpHeaders }from '@angular/common/http';
import { catchError,tap, map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

  export class EmployeeServiceService {
  apiUrl:string="http://localhost:62800/api/employees";
  private httpOptions={
    headers:new HttpHeaders({'Content-Type':'application/json'})
  }
    constructor(private client:HttpClient) { }
    private handleError<T>(operation = 'operation',result?:T){
    return (error:any): Observable<T>=>{
      //TODO:send the error to remote logging infrastructure
      console.error(error);
      return of(result as T);
    };
  }

getEmployeeList():Observable<Employee[]>{
  return this.client.get<Employee[]>(this.apiUrl)
  .pipe(tap(employee=>console.log('Employees fetched.count'+ employee.length)),
  catchError(this.handleError('getEmployeeList',[])));
}
getEmployeeById(id):Observable<Employee>{
  const url = `${this.apiUrl}/${id}`;
  return this.client.get<Employee>(url)
  .pipe(tap(employee=>console.log('Employee fetched with id=' + employee.Id)),
  catchError(this.handleError<Employee>('getEmployeeById')));
}
  
AddEmployee(employee):Observable<Employee>{
  
  return this.client.put<Employee>(this.apiUrl,
    employee,this.httpOptions)
    .pipe
    (tap((employee:Employee) =>
    console.log(` added employee with id =${employee.Id}`)),
  catchError(this.handleError<Employee>(`AddEmployee`))
    );
  }
updateEmployee(id,employee):Observable<Employee>{
  const url = `${this.apiUrl}/${id}`;
  return this.client.put<Employee>(url,
    employee,this.httpOptions)
    .pipe
    (tap((employee:Employee) =>
    console.log(` added employee with id =${employee.Id}`)),
  catchError(this.handleError<Employee>(`updateEmployee`))
    );


  }
}