export interface Employee {
    Id:number;
    Name:string;
    DateOfBirth:Date;
    DateOfJoining:Date;
    Department:string;
    Salary:number;
}
